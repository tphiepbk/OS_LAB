// readline.h
#include <stdio.h>

#ifndef READ_LINE_H
#define READ_LINE_H

int read_line(char* str);

#endif