#ifndef SUB_H_
#define SUB_H_
int sub(int a, int b);
#endif
