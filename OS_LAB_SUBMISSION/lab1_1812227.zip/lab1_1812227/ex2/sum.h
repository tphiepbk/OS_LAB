#ifndef SUM_H_
#define SUM_H_
int sum(int a, int b);
#endif
